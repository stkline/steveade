package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageAction.TestBase;

public class Waiter extends TestBase{

	
	public Waiter(WebDriver driver) {
		super(driver);
		 
	}

	public void waitForElement(WebElement elementToWaitFor) {
		WebDriverWait wait = new WebDriverWait (driver, 5);
		wait.until(ExpectedConditions.visibilityOf(elementToWaitFor));
		
	}
}
