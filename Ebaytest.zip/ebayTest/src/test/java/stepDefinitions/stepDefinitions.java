package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageAction.LandingPage;
import pageAction.ProductsPage;
import pageAction.TestBase;

public class stepDefinitions extends TestBase{


	

ProductsPage Pp = new ProductsPage(driver);
LandingPage lp = new LandingPage(driver);


	@Given("^I am a non-registered customer$")
	public void i_am_a_non_registered_customer()  {
		System.out.println("I am a customer");
	}

	@Given("^I navigate to www\\.ebay\\.co\\.uk$")
	public void i_navigate_to_www_ebay_co_uk()  {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.ebay.co.uk");
	}
	@When("^I search for an item$")
	public void i_search_for_an_item()  {
	  lp.searchItem("Black cement dye");
	}

	@Then("^I get a list of matching results$")
	public void i_get_a_list_of_matching_results()  {
		Pp.verifySearchResult();
	}

	@Then("^the resulting items cards show: postage price, No of bids, price or show BuyItNow tag$")
	public void the_resulting_items_cards_show_postage_price_No_of_bids_price_or_show_BuyItNow_tag() {
		Pp.verifyItemCart();
	}

	@Then("^I can sort the results by Lowest Price$")
	public void i_can_sort_the_results_by_Lowest_Price()  {
		Pp.selectFromDropdown("Lowest price");
	}

	@Then("^the results are listed in the page in the correct order$")
	public void the_results_are_listed_in_the_page_in_the_correct_order()  {
		Pp.verifySortOrder("Lowest price");
	}

	@Then("^I can sort the results by Highest Price$")
	public void i_can_sort_the_results_by_Highest_Price() {
		Pp.selectFromDropdown("Highest price");
		Pp.verifySortOrder("Highest price");
	}

	@Then("^I can filter the results by 'Buy it now'$")
	public void i_can_filter_the_results_by_Buy_it_now()  {
		Pp.viewItemThatCanBePurchasedImmedicately();
	}
}
