package pageAction;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utils.Waiter;


public class LandingPage {
 WebDriver driver;
 Waiter wait = new Waiter(driver);


 @FindBy(xpath="//*[@id='gh-ac']")
 WebElement searchField;
 
 @FindBy(xpath="//*[@id='gh-btn']")
 WebElement searchButton;
 
 @FindBy(xpath="//*[@id=\"e1-1\"]")
 WebElement sortFilter;
 

 
public LandingPage(WebDriver driver) {
	 this.driver = driver;
	 PageFactory.initElements(driver, this);	 
 }

public void searchItem(String ProductName) {
	searchField.sendKeys(ProductName);	
	 wait.waitForElement(sortFilter);
	 searchButton.click();
}

}
