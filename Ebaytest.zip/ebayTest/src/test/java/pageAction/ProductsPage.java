package pageAction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import utils.Waiter;

public class ProductsPage {
	 public WebDriver driver;
	 
	 Waiter w ;
	 @FindBy(xpath="//*[@id=\"item443e516791\"]/ul[@_sp[1]]//li//span[@class='logoBin']")
	 WebElement buyItNowLabel;
	 
	 @FindBy(xpath="//*[@id=\"item443e516791\"]/ul[@_sp[1]]//li//span[@class='bfsp']")
	 WebElement postageLabel;
	 
	 @FindBy(xpath="//*[@id=\"DashSortByContainer\"]/ul[1]/li/div/span")
	 WebElement dropDownButton;
	 
	 @FindBy(xpath="//*[@id=\"SortMenu\"]//li")
	 WebElement dropDownList;
	 
	 @FindBy(xpath="//*[@id=\"cbelm\"]/div[1]/div[2]/span")
	 WebElement buyItNowButton;
	 
	

	 public ProductsPage(WebDriver driver) {
	 	 this.driver = driver;
	 	 PageFactory.initElements(driver, this);	 
	  }
	 
public void selectFromDropdown(String itemName) {
	
}

public void verifySearchResult() {
	//String productLabel = null;
	List<WebElement> productList = driver.findElements(By.xpath("//div[@id='spf_content']//div[@id='rsTabs']//div//w-root//div//div[2]//ul[@id='ListViewInner']//li[@id]//h3"));
   for(WebElement product: productList) {
	   
	   String productLabel = product.getText();
	   Assert.assertTrue(productLabel.contains("Black"));
	   Assert.assertTrue(productLabel.contains("Cement"));
	   Assert.assertTrue(productLabel.contains("Dye"));
   }
  
}
public void verifyItemCart()
{
	Assert.assertEquals("Buy it now", buyItNowLabel.getText());
	Assert.assertEquals("Free Postage", postageLabel.getText());
}

    public void selectItemFromDropdown(String ItemName)
    {
    	
    	Actions action = new Actions (driver);
    	action.moveToElement(dropDownButton).build().perform();
    	w = new Waiter(driver);
    	w.waitForElement(dropDownList);
    	Select selector = new Select(dropDownList);
    	selector.selectByVisibleText(ItemName);
    }
    
    public void verifySortOrder(String sortByName) {
    	if(sortByName.equalsIgnoreCase("Lowest price")) {
    		List<WebElement> productPriceList = driver.findElements(By.xpath("//div[@id='spf_content']//div[@id='rsTabs']//div//w-root//div//div[2]//ul[@id='ListViewInner']//li[@id]//ul[@_sp]//li//span[@class='bold']"));
    		ArrayList<Integer> productPrice = new ArrayList<>();
    	for (WebElement prices:productPriceList)
    	{
    		int price = Integer.parseInt(prices.getText());
    		productPrice.add(price);
    	} 
    	
    	int firstProductPrice  = productPrice.get(0);
    	int secondProductPrice  = productPrice.get(1);
    	int thirdProductPrice  = productPrice.get(2);
    	int fourthProductPrice  = productPrice.get(3);
    	int fifthProductPrice  = productPrice.get(4);
    	int sixthProductPrice  = productPrice.get(5);
    	 
    	Assert.assertTrue(firstProductPrice<= secondProductPrice);
    	Assert.assertTrue(secondProductPrice<= thirdProductPrice);
    	Assert.assertTrue(thirdProductPrice<= fourthProductPrice);
    	Assert.assertTrue(fourthProductPrice<= fifthProductPrice);
    	Assert.assertTrue(fifthProductPrice<= sixthProductPrice);
    	
    	}
    	else if (sortByName.equalsIgnoreCase("Highest price")) {
    		List<WebElement> productPriceList = driver.findElements(By.xpath("//div[@id='spf_content']//div[@id='rsTabs']//div//w-root//div//div[2]//ul[@id='ListViewInner']//li[@id]//ul[@_sp]//li//span[@class='bold']"));
    		ArrayList<Integer> productPrice = new ArrayList<>();
    	for (WebElement prices:productPriceList)
    	{
    		int price = Integer.parseInt(prices.getText());
    		productPrice.add(price);
    	} 
    	
    	int firstProductPrice  = productPrice.get(0);
    	int secondProductPrice  = productPrice.get(1);
    	int thirdProductPrice  = productPrice.get(2);
    	int fourthProductPrice  = productPrice.get(3);
    	int fifthProductPrice  = productPrice.get(4);
    	int sixthProductPrice  = productPrice.get(5);
    	 
    	Assert.assertTrue(firstProductPrice>= secondProductPrice);
    	Assert.assertTrue(secondProductPrice>= thirdProductPrice);
    	Assert.assertTrue(thirdProductPrice>= fourthProductPrice);
    	Assert.assertTrue(fourthProductPrice>= fifthProductPrice);
    	Assert.assertTrue(fifthProductPrice>= sixthProductPrice);	
    		
    	}
         
    }
    
    public void viewItemThatCanBePurchasedImmedicately(){
    	buyItNowButton.click();
    	List<WebElement> productsThatCanBePurchasedNow = driver.findElements(By.xpath("//div[@id='spf_content']//div[@id='rsTabs']//div//w-root//div//div[2]//ul[@id='ListViewInner']//li[@id]//ul[@_sp]//li//span[@class='bold']"));
		ArrayList<String> buyNowTags = new ArrayList<>();
		for(WebElement tag:productsThatCanBePurchasedNow) {
			
			String tagLabel = tag.getAttribute("innerHTML");
			buyNowTags.add(tagLabel);
		}
    	
		for(String tags:buyNowTags) {
			
			Assert.assertTrue(tags.contains("Buy it now"));
		}
    	
    }
}
